from flask import Flask, jsonify, request, render_template
import sqlite3
from datetime import datetime, timedelta
import sys

app = Flask(__name__)

# ========== DATABASE INITIALIZATION ==========
def initialize_database():
    conn = sqlite3.connect("timetable_system.db")
    cursor = conn.cursor()

    # Teachers table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS teachers (
        teacher_id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE NOT NULL,
        max_hours INTEGER DEFAULT 16 CHECK(max_hours >= 1)
    )
    """)

    # Subjects table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS subjects (
        subject_id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE NOT NULL,
        code TEXT UNIQUE NOT NULL
    )
    """)

    # Class groups table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS class_groups (
        group_id INTEGER PRIMARY KEY AUTOINCREMENT,
        year INTEGER NOT NULL CHECK(year BETWEEN 1 AND 5),
        division TEXT NOT NULL CHECK(division IN ('A', 'B', 'C', 'D')),
        UNIQUE(year, division)
    )
    """)

    # Rooms table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS rooms (
        room_id INTEGER PRIMARY KEY AUTOINCREMENT,
        room_number TEXT UNIQUE NOT NULL,
        capacity INTEGER CHECK(capacity > 0)
    )
    """)

    # Timetable slots with 1-hour minimum
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS timetable_slots (
        slot_id INTEGER PRIMARY KEY AUTOINCREMENT,
        day TEXT NOT NULL CHECK(day IN ('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday')),
        start_time TEXT NOT NULL CHECK(start_time GLOB '[0-9][0-9]:[0-9][0-9]'),
        duration REAL NOT NULL CHECK(duration >= 1 AND duration <= 8),
        subject_id INTEGER NOT NULL,
        teacher_id INTEGER NOT NULL,
        group_id INTEGER NOT NULL,
        room_id INTEGER NOT NULL,
        FOREIGN KEY(subject_id) REFERENCES subjects(subject_id),
        FOREIGN KEY(teacher_id) REFERENCES teachers(teacher_id),
        FOREIGN KEY(group_id) REFERENCES class_groups(group_id),
        FOREIGN KEY(room_id) REFERENCES rooms(room_id),
        UNIQUE(day, start_time, group_id),
        UNIQUE(day, start_time, teacher_id),
        UNIQUE(day, start_time, room_id)
    )
    """)

    conn.commit()
    conn.close()

# Serve the HTML file
@app.route("/")
def index():
    return render_template("index.html")

# API to fetch all teachers
@app.route("/api/teachers", methods=["GET"])
def get_teachers():
    conn = sqlite3.connect("timetable_system.db")
    cursor = conn.cursor()
    cursor.execute("SELECT teacher_id, name, max_hours FROM teachers")
    teachers = [{"id": row[0], "name": row[1], "max_hours": row[2]} for row in cursor.fetchall()]
    conn.close()
    return jsonify(teachers)

# API to add a teacher
@app.route("/api/teachers", methods=["POST"])
def add_teacher():
    data = request.json
    conn = sqlite3.connect("timetable_system.db")
    try:
        conn.execute("INSERT INTO teachers (name, max_hours) VALUES (?, ?)", (data["name"], data["max_hours"]))
        conn.commit()
        return jsonify({"message": "Teacher added successfully"}), 201
    except sqlite3.IntegrityError:
        return jsonify({"error": "Teacher already exists"}), 400
    finally:
        conn.close()

# API to update a teacher
@app.route("/api/teachers/<int:teacher_id>", methods=["PUT"])
def update_teacher(teacher_id):
    data = request.json
    conn = sqlite3.connect("timetable_system.db")
    try:
        cursor = conn.cursor()
        cursor.execute(
            "UPDATE teachers SET name = ?, max_hours = ? WHERE teacher_id = ?",
            (data["name"], data["max_hours"], teacher_id),
        )
        if cursor.rowcount == 0:
            return jsonify({"error": "Teacher not found"}), 404
        conn.commit()
        return jsonify({"message": "Teacher updated successfully"}), 200
    except sqlite3.IntegrityError:
        return jsonify({"error": "Teacher with this name already exists"}), 400
    finally:
        conn.close()

# API to fetch all subjects
@app.route("/api/subjects", methods=["GET"])
def get_subjects():
    conn = sqlite3.connect("timetable_system.db")
    cursor = conn.cursor()
    cursor.execute("SELECT subject_id, name, code FROM subjects")
    subjects = [{"id": row[0], "name": row[1], "code": row[2]} for row in cursor.fetchall()]
    conn.close()
    return jsonify(subjects)

# API to add a subject
@app.route("/api/subjects", methods=["POST"])
def add_subject():
    data = request.json
    conn = sqlite3.connect("timetable_system.db")
    try:
        conn.execute(
            "INSERT INTO subjects (name, code) VALUES (?, ?)",
            (data["name"], data["code"]),
        )
        conn.commit()
        return jsonify({"message": "Subject added successfully"}), 201
    except sqlite3.IntegrityError:
        return jsonify({"error": "Subject already exists"}), 400
    finally:
        conn.close()

# API to fetch all class groups
@app.route("/api/class-groups", methods=["GET"])
def get_class_groups():
    conn = sqlite3.connect("timetable_system.db")
    cursor = conn.cursor()
    cursor.execute("SELECT group_id, year, division FROM class_groups")
    groups = [{"id": row[0], "year": row[1], "division": row[2]} for row in cursor.fetchall()]
    conn.close()
    return jsonify(groups)

# API to add a class group
@app.route("/api/class-groups", methods=["POST"])
def add_class_group():
    data = request.json
    conn = sqlite3.connect("timetable_system.db")
    try:
        conn.execute(
            "INSERT INTO class_groups (year, division) VALUES (?, ?)",
            (data["year"], data["division"]),
        )
        conn.commit()
        return jsonify({"message": "Class group added successfully"}), 201
    except sqlite3.IntegrityError:
        return jsonify({"error": "Class group already exists"}), 400
    finally:
        conn.close()

# API to fetch all rooms
@app.route("/api/rooms", methods=["GET"])
def get_rooms():
    conn = sqlite3.connect("timetable_system.db")
    cursor = conn.cursor()
    cursor.execute("SELECT room_id, room_number, capacity FROM rooms")
    rooms = [{"id": row[0], "room_number": row[1], "capacity": row[2]} for row in cursor.fetchall()]
    conn.close()
    return jsonify(rooms)

# API to add a room
@app.route("/api/rooms", methods=["POST"])
def add_room():
    data = request.json
    conn = sqlite3.connect("timetable_system.db")
    try:
        conn.execute(
            "INSERT INTO rooms (room_number, capacity) VALUES (?, ?)",
            (data["room_number"], data["capacity"]),
        )
        conn.commit()
        return jsonify({"message": "Room added successfully"}), 201
    except sqlite3.IntegrityError:
        return jsonify({"error": "Room already exists"}), 400
    finally:
        conn.close()

# API to fetch all timetable slots
@app.route("/api/timetable-slots", methods=["GET"])
def get_timetable_slots():
    conn = sqlite3.connect("timetable_system.db")
    cursor = conn.cursor()
    cursor.execute("""
        SELECT ts.slot_id, ts.day, ts.start_time, ts.duration, sub.name, tch.name, cg.year || cg.division, rm.room_number
        FROM timetable_slots ts
        JOIN subjects sub ON ts.subject_id = sub.subject_id
        JOIN teachers tch ON ts.teacher_id = tch.teacher_id
        JOIN class_groups cg ON ts.group_id = cg.group_id
        JOIN rooms rm ON ts.room_id = rm.room_id
    """)
    slots = [
        {
            "id": row[0],
            "day": row[1],
            "start_time": row[2],
            "duration": row[3],
            "subject": row[4],
            "teacher": row[5],
            "class_group": row[6],
            "room": row[7],
        }
        for row in cursor.fetchall()
    ]
    conn.close()
    return jsonify(slots)

# API to fetch timetable slots by teacher
@app.route("/api/timetable-slots/teacher/<int:teacher_id>", methods=["GET"])
def get_timetable_by_teacher(teacher_id):
    conn = sqlite3.connect("timetable_system.db")
    cursor = conn.cursor()
    cursor.execute("""
        SELECT ts.slot_id, ts.day, ts.start_time, ts.duration, sub.name, cg.year || cg.division, rm.room_number
        FROM timetable_slots ts
        JOIN subjects sub ON ts.subject_id = sub.subject_id
        JOIN teachers tch ON ts.teacher_id = tch.teacher_id
        JOIN class_groups cg ON ts.group_id = cg.group_id
        JOIN rooms rm ON ts.room_id = rm.room_id
        WHERE ts.teacher_id = ?
    """, (teacher_id,))
    slots = [
        {
            "id": row[0],
            "day": row[1],
            "start_time": row[2],
            "duration": row[3],
            "subject": row[4],
            "class_group": row[5],
            "room": row[6],
        }
        for row in cursor.fetchall()
    ]
    conn.close()
    return jsonify(slots)

# API to fetch timetable slots by class group
@app.route("/api/timetable-slots/class-group/<int:group_id>", methods=["GET"])
def get_timetable_by_class_group(group_id):
    conn = sqlite3.connect("timetable_system.db")
    cursor = conn.cursor()
    cursor.execute("""
        SELECT ts.slot_id, ts.day, ts.start_time, ts.duration, sub.name, tch.name, rm.room_number
        FROM timetable_slots ts
        JOIN subjects sub ON ts.subject_id = sub.subject_id
        JOIN teachers tch ON ts.teacher_id = tch.teacher_id
        JOIN rooms rm ON ts.room_id = rm.room_id
        WHERE ts.group_id = ?
    """, (group_id,))
    slots = [
        {
            "id": row[0],
            "day": row[1],
            "start_time": row[2],
            "duration": row[3],
            "subject": row[4],
            "teacher": row[5],
            "room": row[6],
        }
        for row in cursor.fetchall()
    ]
    conn.close()
    return jsonify(slots)

# API to add a timetable slot
@app.route("/api/timetable-slots", methods=["POST"])
def add_timetable_slot():
    data = request.json
    conn = sqlite3.connect("timetable_system.db")
    cursor = conn.cursor()
    try:
        # 1. Check for time overlaps
        cursor.execute(
            """
            SELECT slot_id, start_time, duration, teacher_id, group_id, room_id
            FROM timetable_slots
            WHERE day = ? AND (teacher_id = ? OR group_id = ? OR room_id = ?)
            """,
            (data["day"], data["teacher_id"], data["group_id"], data["room_id"]),
        )
        existing_slots = cursor.fetchall()

        new_start = datetime.strptime(data["start_time"], "%H:%M")
        new_end = new_start + timedelta(hours=data["duration"])

        for slot in existing_slots:
            existing_start = datetime.strptime(slot[1], "%H:%M")
            existing_end = existing_start + timedelta(hours=slot[2])

            if new_start < existing_end and new_end > existing_start:
                # Retrieve Teacher, Group, Room info for the conflicting slot.
                cursor.execute(
                    """
                    SELECT t.name, cg.year || cg.division, r.room_number
                    FROM teachers t, class_groups cg, rooms r, timetable_slots ts
                    WHERE ts.teacher_id = t.teacher_id AND ts.group_id = cg.group_id AND ts.room_id = r.room_id
                    AND ts.slot_id = ?
                    """, (slot[0],)
                )
                conflict_details = cursor.fetchone()

                return jsonify({
                    "error": "Time slot conflict detected",
                    "conflict_slot_id": slot[0],
                    "conflict_start_time": slot[1],
                    "conflict_teacher": conflict_details[0],
                    "conflict_class_group": conflict_details[1],
                    "conflict_room": conflict_details[2],
                }), 400

        # 2. Enforce teacher's max_hours
        cursor.execute(
            """
            SELECT SUM(duration)
            FROM timetable_slots
            WHERE teacher_id = ?
            """,
            (data["teacher_id"],),
        )
        total_hours = cursor.fetchone()[0] or 0

        cursor.execute(
            """
            SELECT max_hours, name
            FROM teachers
            WHERE teacher_id = ?
            """,
            (data["teacher_id"],),
        )
        teacher_data = cursor.fetchone()
        max_hours = teacher_data[0]
        teacher_name = teacher_data[1]

        if total_hours + data["duration"] > max_hours:
            return jsonify({
                "error": "Teacher's max hours exceeded",
                "teacher_name": teacher_name,
                "current_hours": total_hours,
                "max_hours": max_hours,
            }), 400

        # Insert the new slot if no conflicts
        conn.execute(
            """
            INSERT INTO timetable_slots (day, start_time, duration, subject_id, teacher_id, group_id, room_id)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                data["day"],
                data["start_time"],
                data["duration"],
                data["subject_id"],
                data["teacher_id"],
                data["group_id"],
                data["room_id"],
            ),
        )
        conn.commit()
        return jsonify({"message": "Timetable slot added successfully"}), 201

    except sqlite3.IntegrityError as e:
        return jsonify({"error": "Conflict detected or invalid data"}), 400
    except ValueError as e:
        return jsonify({"error": "Invalid time format"}), 400
    finally:
        conn.close()

# Run the app
if __name__ == "__main__":
    initialize_database()
    app.run(debug=True)